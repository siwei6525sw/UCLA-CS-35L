#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include "fprintftime.h"
#define FPRINTFTIME 1
#include "strftime.c"
