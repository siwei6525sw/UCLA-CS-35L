int posix2_version (void);
