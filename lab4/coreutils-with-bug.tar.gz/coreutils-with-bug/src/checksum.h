enum
{
  ALG_MD5 = 1,
  ALG_SHA1
};

extern int algorithm;
