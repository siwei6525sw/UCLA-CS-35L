#include "checksum.h"
int algorithm = ALG_MD5;
